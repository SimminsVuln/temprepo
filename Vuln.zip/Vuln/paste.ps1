Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Time interval in seconds
$interval = 5

while ($true) {
    [System.Windows.Forms.SendKeys]::SendWait("^{v}")
    Start-Sleep -Seconds $interval
}