# ====== Process Each Result and Extract the Required Fields ======
$processedResults = foreach ($result in $response.results) {
    # For cve_ids: join array of strings with semicolons
    $cveIdsJoined = if ($result.cve_ids) { 
        $result.cve_ids -join ';'
    } else { 
        ""
    }

    # For ext_references: get only those where the value starts with http(s)://
    $extRefsJoined = if ($result.ext_references) {
        ($result.ext_references | Where-Object { 
            $_.value -match '^https?://'
        } | ForEach-Object { 
            $_.value 
        }) -join ';'
    } else { 
        ""
    }

    # For cvss_v3s: extract only the score
    $cvssV3Scores = if ($result.cvss_v3s) {
        ($result.cvss_v3s | ForEach-Object { $_.calculated_cvss_base_score })
    } else { 
        @()
    }
    $cvssV3Joined = $cvssV3Scores -join ';'

    # For cvss_v4s: extract only the score
    $cvssV4Scores = if ($result.cvss_v4s) {
        ($result.cvss_v4s | ForEach-Object { $_.score })
    } else { 
        @()
    }
    $cvssV4Joined = $cvssV4Scores -join ';'

    # Extract risk rating
    $riskRating = if ($result.risk_rating) { $result.risk_rating.ToUpper() } else { "" }

    # Determine if CVSS is 8.0+ AND risk rating is HIGH or CRITICAL
    $highCvssV3 = $cvssV3Scores | Where-Object { $_ -ge 8.0 }
    $highCvssV4 = $cvssV4Scores | Where-Object { $_ -ge 8.0 }
    $watchlist = if (($highCvssV3 -or $highCvssV4) -and ($riskRating -eq "HIGH" -or $riskRating -eq "CRITICAL")) { "Yes" } else { "No" }

    # For products: extract only the 'name' field from each nested object and join them.
    $productNames = if ($result.products) {
        $result.products | ForEach-Object { $_.name }
    } else {
        @()
    }
    $productsJoined = $productNames -join ';'

    # For vendors: extract only the 'name' field from each nested object and join them.
    $vendorsJoined = if ($result.vendors) {
        $result.vendors | ForEach-Object { $_.name }
    } else {
        ""
    }

    # Create a custom object with the desired properties.
    [PSCustomObject]@{
        title          = $result.title
        cve_ids        = $cveIdsJoined
        ext_references = $extRefsJoined
        cvss_v3s       = $cvssV3Joined
        cvss_v4s       = $cvssV4Joined
        risk_rating    = $riskRating
        products       = $productsJoined
        vendors        = $vendorsJoined
        Watchlist      = $watchlist  # New column for watchlist status
    }
}

# ====== Export the Results to a CSV File ======
$processedResults | Export-Csv -Path "flashpoint.csv" -NoTypeInformation

# Also echo the processed output to the command line in a formatted table.
$processedResults | Format-Table -AutoSize

Write-Output "Processing complete. See flashpoint.csv for results."
