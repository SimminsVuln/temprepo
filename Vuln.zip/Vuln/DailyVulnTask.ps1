# Set the working directory
Set-Location "C:\Scripts\VulnTracker"

# Run Flexera Script
Write-Output "Starting Flexera.ps1..."
Start-Process powershell -ArgumentList "-File .\flexera.ps1" -NoNewWindow -Wait

# Wait for 4 minutes
Start-Sleep -Seconds 240  # 4 minutes

# Run SecCleanup Script
Write-Output "Starting SecCleanup.ps1..."
Start-Process powershell -ArgumentList "-File .\SecCleanup.ps1" -NoNewWindow -Wait

# Wait for 4 minutes
Start-Sleep -Seconds 240  # 4 minutes

# Run SecCleanup Script
Write-Output "Starting SecCleanup.ps1..."
Start-Process powershell -ArgumentList "-File .\Flashpoint2.ps1" -NoNewWindow -Wait

# Send completion notification
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime]
$template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText01)
$toastXml = $template.SelectSingleNode("//text")
$toastXml.InnerText = "Vulnerability Tracker completed successfully!"
$toast = [Windows.UI.Notifications.ToastNotification]::new($template)
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("VulnTracker Task").Show($toast)

# Log completion time
$logMessage = "$(Get-Date) - VulnTracker task completed."
$logFile = "C:\Users\chris\OneDrive\Documents\VulnTracker\TaskLog.txt"
Add-Content -Path $logFile -Value $logMessage
