# API Key from the CVE Crowd API
$API_KEY = "adc54222-58f3-4c02-aa8f-3c5be19e69ac"
$BaseURL = "https://api.cvecrowd.com/v2/cves"
$Headers = @{
    "Authorization" = "Bearer $API_KEY"
}

# Fetch CVEs from the past 1 day
try {
    $CVEListResponse = Invoke-RestMethod -Uri "$BaseURL" -Headers $Headers -Method Get
    if (-not $CVEListResponse) {
        Write-Error "No CVEs found for the past day."
        exit
    }
} catch {
    Write-Error "Error retrieving CVE list: $_"
    exit
}

# Initialize CSV file
$CSVFilePath = "crowdTest.csv"
$CSVHeaders = "cve_id,base_score,vendor,product,value-url"
Set-Content -Path $CSVFilePath -Value $CSVHeaders

# Loop through each CVE and get details
foreach ($CVE_ID in $CVEListResponse) {
    $CVE_Detail_Url = "$BaseURL/$CVE_ID"
    try {
        $CVE_Detail_Response = Invoke-RestMethod -Uri $CVE_Detail_Url -Headers $Headers -Method Get
        
        # Extract necessary fields
        $CVE_ID_Value = $CVE_Detail_Response.cve_id
        $BaseScore = $CVE_Detail_Response.base_score
        $Vendor = $CVE_Detail_Response.vendor
        $Product = $CVE_Detail_Response.product
        $ValueURL = "$BaseURL/$CVE_ID"

        # Append to CSV file
        "$CVE_ID_Value,$BaseScore,$Vendor,$Product,$ValueURL" | Out-File -Append -FilePath $CSVFilePath
    } catch {
        Write-Error "Error retrieving details for CVE: $CVE_ID. $_"
    }
}

Write-Output "CSV export completed: $CSVFilePath"